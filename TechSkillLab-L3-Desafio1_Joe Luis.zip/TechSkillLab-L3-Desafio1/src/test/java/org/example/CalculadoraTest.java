package org.example;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CalculadoraTest {

    int num1, num2;
    double num3, num4;

    @BeforeEach
     void setUp(){
        num1 = 30;
        num2 = 15;
        num3 = 8.8;
        num4 = 7.3;
    }

    @Test
    void sumar_exitoso() {
        assertEquals(45, Calculadora.sumar(num1,num2));
    }

    @Test
    void sumar_fallido() {
        assertNotEquals(15, Calculadora.sumar(num1,num2));
    }

    @Test
    void restar_exitoso() {
        assertEquals(15, Calculadora.restar(num1,num2));
    }

    @Test
    void restar_fallido() {
        assertNotEquals(8, Calculadora.restar(num1,num2));
    }

    @Test
    void multiplicar_exitoso() {
        assertEquals(450, Calculadora.multiplicar(num1,num2));
    }

    @Test
    void multiplicar_fallido() {
        assertNotEquals(50, Calculadora.multiplicar(num1,num2));
    }

    @Test
    void dividir_exitoso() {
        assertEquals(2, Calculadora.dividir(num1,num2));
    }

    @Test
    void dividir_fallido() {
        assertNotEquals(7, Calculadora.dividir(num1,num2));
    }

    @Test
    void sumar_exitoso_d() {
        double res = Calculadora.sumar(num3, num4);
        assertEquals(16.1, res);
        assertTrue(res > 0);
    }

    @Test
    void restar_exitoso_d() {
        double res = Calculadora.restar(num3, num4);
        assertEquals(1.5, res);
    }

    @Test
    void multiplicar_existoso_d() {
        double res = Calculadora.multiplicar(num4, num3);
        assertEquals(64.24, res);
    }

    @Test
    void dividir_decimales_exitoso() {
        assertDoesNotThrow(() -> Calculadora.dividir(num3, num4));
    }

    @Test
    void dividir_por_cero() {
        assertTrue(Double.isNaN(Calculadora.dividir(0.0, 0.0)));
    }

    @Test
    void dividir_Cero() {
        assertThrows(Exception.class, ()-> Calculadora.dividir_cero(num3,0.0));
    }
}